package com.sc.testlib

import kotlinx.datetime.*
import kotlin.math.abs

class TimeZoneHelperImpl:TimeZoneHelper {
    override fun getTimeZoneStrings(): List<String> {
        return TimeZone.availableZoneIds.sorted()
    }

    override fun currentTime(): String {
     // Step 1:
        val currentMoment:Instant = Clock.System.now()
        //Step 2:
        val dateTime:LocalDateTime= currentMoment.toLocalDateTime(TimeZone.currentSystemDefault())
        //Step 3:
        return formatDateTime(dateTime)
    }

    override fun currentTimeZone(): String {
        val timeZone = TimeZone.currentSystemDefault()
        return  timeZone.toString()
    }

    override fun hoursFromTimeZone(otherTimZoneId: String): Double {
       val currentTimeZone = TimeZone.currentSystemDefault()
        val currentUTCInstant:Instant = Clock.System.now()

        val otherTimeZone = TimeZone.of(otherTimZoneId)
        val currentDateTime:LocalDateTime = currentUTCInstant.toLocalDateTime(currentTimeZone)

        val currentOtherDateTime:LocalDateTime = currentUTCInstant.toLocalDateTime(otherTimeZone)
         return abs((currentDateTime.hour- currentOtherDateTime.hour) * 1.0)
    }

    override fun getTime(timeZoneId: String): String {
       //Step 1:
        val timeZone = TimeZone.of(timeZoneId)
        //Step 2: get current time
        val currentMoment: Instant = Clock.System.now()
        //Step 3:
        val dateTime:LocalDateTime= currentMoment.toLocalDateTime(timeZone)
        return formatDateTime(dateTime)
    }

    override fun getDate(timeZoneId: String): String {
       val timezone = TimeZone.of(timeZoneId)
        val currentMoment:Instant = Clock.System.now()
        val dateTime: LocalDateTime = currentMoment.toLocalDateTime(timezone)

        return "${dateTime.dayOfWeek.name.lowercase().replaceFirstChar { 
            it.uppercase()
        }}, "+"${dateTime.month.name.lowercase().replaceFirstChar { 
            it.uppercase()
        }} ${dateTime.date.dayOfMonth}"
    }



    private fun formatDateTime(dateTime: LocalDateTime): String {
        // 1
        val stringBuilder = StringBuilder()
        // 2
        var hour = dateTime.hour
        val minute = dateTime.minute
        var amPm = " am"
        // 3
        // For 12
        if (hour > 12) {
            amPm = " pm"
            hour -= 12
        }
        // 4
        stringBuilder.append(hour.toString())
        stringBuilder.append(":")
        // 5
        if (minute < 10) {
            stringBuilder.append('0')
        }
        stringBuilder.append(minute.toString())
        stringBuilder.append(amPm)
        // 6
        return stringBuilder.toString()
    }

}