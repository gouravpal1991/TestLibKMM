package com.sc.testlib

interface TimeZoneHelper {
    fun getTimeZoneStrings():List<String>
    fun currentTime():String
    fun currentTimeZone():String
    fun hoursFromTimeZone(otherTimZoneId:String):Double
    fun getTime(timeZoneId:String):String
    fun getDate(timeZoneId:String):String
}